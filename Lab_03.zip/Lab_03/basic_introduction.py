name = "Ayesha Imran"
age = 17
height = 5.4
is_student = True

print(name)
print("Age:", age)
print("Height:", height)
print("Student:", is_student)
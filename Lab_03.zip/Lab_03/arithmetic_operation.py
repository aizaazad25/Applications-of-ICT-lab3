a = 10
b = 3

print("Addition:", a +b)
print("Subtraction:", a - b)
print("Multiplication:", a * b)
print("Division:", a / b)
print("Floor divison:", a //b )
print("Modulus:", a % b)
print("Exponent:", a ** b)